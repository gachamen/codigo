      <div class="one-third services"> <img class="icon_left" src="images/icons/book.png" alt="icon" />
        <h2>Clean Design</h2>
        <p> Sir Francis watched the procession with a sad countenance, and, turning to the guide, said, &quot;A suttee.&quot; The Parsee nodded, and put his finger to his lips.</p>
        <a href="#" class="more">Read more</a></div>
      <div class="one-third services"> <img class="icon_left" src="images/icons/monitor.png" alt="icon"/>
        <h2>Great Functionality</h2>
        <p> Leaving Powell's body where it lay on the ledge I crept into the cave to reconnoiter.  I found a large chamber, possibly a hundred feet in diameter.</p>
        <a href="#" class="more">Read more</a></div>
      <div class="hr"></div>
      <div class="one-third services"> <img class="icon_left" src="images/icons/iphone.png" alt="icon" />
        <h2>Easy Customizable</h2>
        <p> Several times I thought I heard faint sounds behind me as of somebody moving cautiously, but eventually even these ceased, and I was left to the contemplation of my position...</p>
        <a href="#" class="more">Read more</a></div>
      <div class="one-third services"> <img class="icon_left" src="images/icons/drive.png" alt="icon" />
        <h2>Beautiful Colors</h2>
        <p> Passepartout, who had been anxiously watching this amateur gymnast, approached him with lively interest, and learned that he had taken flight after an unpleasant domestic scene.</p>
        <a href="#" class="more">Read more</a></div>
      <div class="hr"></div>
      <div class="two-third services"> <img class="icon_left" src="images/icons/monitor.png" alt="icon" />
        <h2>Download it and enjoy it!</h2>
        <p>The King's argument was, that anything that had a head could be  beheaded, and that you weren't to talk nonsense. The Queen's argument was, that if something wasn't done about it in less  than no time she'd have everybody executed, all round. It was this last  remark that had made the whole party look so grave and anxious.</p>
        <a href="#" class="more">Read more</a></div>
      <div class="hr"></div>
      <div id="headerTwitter">
        <h4> <span class="icon">Latest tweet</span> <span class="alltweets"> <a href="http://www.twitter.com/agurghis">All tweets</a></span></h4>
      </div>
      <div id="twitter_update_list"> Please wait while our tweets load <img src="images/images/indicator.gif" alt="loading"/></div>

