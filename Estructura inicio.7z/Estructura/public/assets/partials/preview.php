		<div id="preview_outer">
              <div id="preview_inner">
                    <div>
                        <img src="images/header thumbs/1_b.jpg" alt="Project title" />
                        <a href="#">Project title</a>
                    </div>
                    
                    <div>
                        <img src="images/header thumbs/2_b.jpg" alt="Project title" />
                        <a href="#">Project title</a>
                    </div>
                    
                    <div>
                        <img src="images/header thumbs/3_b.jpg" alt="Project title" />
                        <a href="#">Project title</a>
                    </div>
                    
                    <div>
                        <img src="images/header thumbs/4_b.jpg" alt="Project title" />
                        <a href="#">Project title</a>
                    </div>
                    
                    <div>
                        <img src="images/header thumbs/5_b.jpg" alt="Project title" />
                        <a href="#">Project title</a>
                    </div>
                    
                    <div>
                        <img src="images/header thumbs/6_b.jpg" alt="Project title" />
                        <a href="#">Project title</a>
                    </div>
                    
                    <div>
                        <img src="images/header thumbs/7_b.jpg" alt="Project title" />
                        <a href="#">Project title</a>
                    </div>
                    
                    <div>
                        <img src="images/header thumbs/8_b.jpg" alt="Project title" />
                        <a href="#">Project title</a>
                    </div>
                    
                    <div>
                        <img src="images/header thumbs/9_b.jpg" alt="Project title" />
                        <a href="#">Project title</a>
                    </div>
                    
              </div>
              </div>

