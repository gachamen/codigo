      <div class="on-third-right">
        <h4>Featured work</h4>
        <h5>Featured project title</h5>
        <a href="#"><img src="images/portoflio/1.jpg" class="portfolio" alt="featured"/></a></div>
      <div>
        <h4>What clients said</h4>
        <div class="blockquote">
          <p class="blockquote"> The old man looked at him and silently began to cry. The weak tears of age rolled down his cheeks and all the feebleness of his eighty-seven years showed in his grief-stricken countenance. <cite>– Jack London</cite></p>
        </div>
      </div>
      <div id="twitter">
        <h4> <span class="icon">Latest tweet</span> <span class="alltweets"> <a href="http://www.twitter.com/agurghis">All tweets</a></span></h4>
        <div id="twitter_right"> Please wait while our tweets load <img src="images/images/indicator.gif" alt="loading"/></div>
      </div>
