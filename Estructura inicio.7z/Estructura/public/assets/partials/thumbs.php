	<div id="thumbs">
		<div id="arrow"></div>
		<span><img src="images/header thumbs/1_s.jpg" alt="Project title" /></span>
		<span><img src="images/header thumbs/2_s.jpg" alt="Project title" /></span>
		<span><img src="images/header thumbs/3_s.jpg" alt="Project title" /></span>
		<span><img src="images/header thumbs/4_s.jpg" alt="Project title" /></span>
        <span><img src="images/header thumbs/5_s.jpg" alt="Project title" /></span>
		<span><img src="images/header thumbs/6_s.jpg" alt="Project title" /></span>
		<span><img src="images/header thumbs/7_s.jpg" alt="Project title" /></span>
		<span><img src="images/header thumbs/8_s.jpg" alt="Project title" /></span>
        <span><img src="images/header thumbs/9_s.jpg" alt="Project title" /></span>
	</div>

