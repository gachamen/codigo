
<div id="logo">
	<a href="index.html">
		<img src="images/images/logo.png" alt="Full moon" /></a>
</div>
